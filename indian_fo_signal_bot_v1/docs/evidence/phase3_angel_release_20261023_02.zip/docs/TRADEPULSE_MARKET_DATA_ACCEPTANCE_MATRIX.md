# TradePulse AI - Phase 4 market-data acceptance matrix

Scope: source inspection and deterministic **offline simulation**. Provider-shaped responses replace only urllib transport in `test_phase4_market_data.py`; they are not broker observations. No live broker request, account/profile request, instrument-master download, receipt issuance, production scan, scheduler start or Telegram delivery is authorized by this report.

`PASS` means the specified offline behavior is implemented and demonstrated by passing tests. `FAIL` means a reproducible current defect. `NOT_TESTED` means no matching external acceptance evidence. `BLOCKED` means a required capability or independently established prerequisite is absent. Offline PASS never changes the live result.

The final integrated counts, commands and process exits belong to [TRADEPULSE_PHASE4_ENGINEERING_REPORT.md](TRADEPULSE_PHASE4_ENGINEERING_REPORT.md). The previous reported Upstox HTTP 403 is historical user evidence; its provider/account cause remains unknown. Angel One has no verified live result. The selected broker is never changed or silently failed over.

## Shared validated contract

| Contract element | Existing source and retained evidence | Offline verification / limit |
|---|---|---|
| Provider, exchange, canonical symbol, provider identifier | `instrument_identity.spot_identity`, `check_echo`, `bind_candles`; `brokers.validate_symbol_meta`. Identity is carried in `instrument_identity`, including provider, symbol, identifier, exchange, segment and instrument type. | Both adapters reject mismatches against checked-in mappings. `TestSharedMarketDataContract` and `TestPhase4BrokerAcceptance.test_quote_identity_failure_cannot_request_candles_or_fall_back_to_other_provider`. Response echoes are checked when supplied; no echo is explicitly `REQUEST_BOUND_NO_ECHO`, not independent confirmation. |
| Mapping source and revision | `spot_identity` records `CHECKED_IN_BOTCONFIG_REFERENCE_V1` or an accepted loaded Angel master, plus a digest in `source_revision`. | A digest establishes consistency only. Both current adapters retain `historical_validity=NOT_ESTABLISHED`. |
| Quote prices and observation | Existing `get_quote`/`get_quotes` provider parsing retains validated prices and provider observation time when present. Upstox uses `timestamp`; Angel uses exchange feed/trade time with its explicit IST convention. | Full-quote numeric/schema/identity checks are independent of time freshness. Missing provider time is never replaced by the local clock. Reference quote APIs may return a price with no timestamp; narrow acceptance remains BLOCKED and stops before candles. Currentness is checked before another request and after the candle read. |
| Candle OHLCV, interval and source time | Both adapters feed provider-shaped candle rows into `assess_live_candle_batch` / `enforce_live_candle_batch`. Normalized fields include `timestamp`, OHLCV, `interval_min`, `timestamp_timezone=Asia/Kolkata`, `is_complete`, `is_simulated=False`, `data_mode=LIVE` and bound identity. | Raw timestamps need explicit timezone/epoch evidence; naive, missing, future or malformed values reject. UTC converts to IST without substituting request time. Offline mock tests intentionally exercise the LIVE parser but do not confer live provenance or acceptance. |
| Candle start, end and completion | Normalized `timestamp` is the provider candle **start**. Existing validation derives the end as `min(start + interval, configured session close)` and compares that end with the injected clock; an explicit false completion flag remains false. | There is no separate provider-supplied candle-end field or candle observation timestamp in the wire row. End/completion are derived facts, not invented independent observations. Forming bars can remain visible but are excluded from strategy/readiness evidence; an all-forming batch rejects. |
| Order, gaps and aggregation | `assess_live_candle_batch` rejects duplicate timestamps, wire order violations, gaps, grid/session errors and malformed OHLCV before sorting/deduplication could conceal them. Upstox validates newest-first one-minute rows before existing five-/15-minute aggregation; 30-minute requests use native 30-minute rows. | `TestSharedMarketDataContract` exercises both adapters, including equal completed five-minute prices/volume. Incomplete aggregation buckets cannot establish readiness. |
| Freshness and exchange session | Shared configured policy returns explicit status, reason, expected session, completed-candle count, close lag and `live_signal_allowed`. Scanner boundary revalidates provider/mode and retained data. | Current quotes use configured delay/skew limits. Completed candles use the unchanged interval/delay policy. A fresh prior closing bar may be reference data; it cannot authorize a new closed-session signal. Calendar evidence is weekdays plus configured holidays, not a verified complete NSE calendar. |
| Failure state and safe reporting | Adapter failure categories, resource cleanup and connection checks remain separate from successful authorized-read counters. Diagnostics emit bounded sanitized fields rather than raw responses. | Shared full-wire tests establish successful read -> timeout/schema failure -> disconnected; a successful new response can restore current data proof. An authorized response with invalid data may increment authorization count without passing quote/candle validity. No stale result is returned as a successful replacement. |
| Signal and historical readiness | Existing scanner, identity, readiness and source-qualification gates remain authoritative; narrow diagnostics do not create a receipt or persist data. | Quote PASS does not imply candle PASS. Quote+candle PASS does not imply strategy prerequisites, F&O contracts, historical qualification or profitability. Historical LIVE replay remains blocked. |

## Provider comparison: offline acceptance

| Check | Upstox | Angel One | Primary source / tests |
|---|---|---|---|
| Existing adapter and read-only request boundaries | PASS | PASS | `UpstoxV2Adapter._request_json`; `AngelOneSmartAPIAdapter._request_json`; endpoint allowlist regressions in `TestPhase4BrokerAcceptance`, `TestUpstoxReadOnlyReadiness`, `TestAngelMarketDataSafety`. No competing broker pipeline. |
| Authentication proof distinguished from configured credentials | PASS | PASS | Successful authorized response/counter required; Upstox token digest changes invalidate old proof. Angel session/token rejection invalidates the session. `TestUpstoxReadOnlyReadiness`, `TestAngelMarketDataSafety`, shared Phase 4 counter tests. Seeded fixture sessions are not live authentication. |
| HTTP 400/401/403/404/429/500/599 classification and cleanup | PASS | PASS | `TestPhase4BrokerAcceptance.test_http_failures_close_resources_and_never_increment_authorized_read_count`; existing provider-specific error/cleanup suites. Upstox 401 AUTH_FAILURE, 403 FORBIDDEN, 429 RATE_LIMIT, others HTTP_ERROR. Angel 401 SESSION_EXPIRED; 403/429 retain its existing RATE_LIMIT category and explanatory access-denied wording; others NETWORK_API_FAILURE. These categories do not establish an account cause. |
| Secret-safe provider failure reporting | PASS | PASS | `TestUpstoxHTTPErrorDetails`, `TestAngelMarketDataSafety`: bounded parsing, malformed responses, raw/encoded credentials, safe cause suppression and cleanup. Angel currently discards HTTP response body detail and retains safe status/category; its provider-level JSON errors retain curated sanitized explanations. |
| Quote success and malformed/numeric/identity failure behavior | PASS | PASS | Real adapter normalization under mocked urllib in `TestPhase4BrokerAcceptance`; existing provider-specific quote tests. |
| Missing/stale/previous-day/malformed/naive/boolean/future quote observations | PASS | PASS | `TestPhase4BrokerAcceptance`: acceptance fails or blocks before candles; successful transport alone is not accepted data. |
| Completed candles, unfinished exclusion and unchanged freshness | PASS | PASS | `TestSharedMarketDataContract`; `TestPhase4BrokerAcceptance.test_forming_candle_metadata_does_not_promote_it_to_completed`; only-forming and failed-candle tests. |
| Failed read after previous good response does not retain verified connection | PASS | PASS | Phase 4 timeout, schema failure, HTTP state and subsequent-valid-read tests; E2E checks the top-level signals-allowed status is revoked after an independent failed read even while older candle evidence remains fresh. Scanner safety tests verify no live-ready signal on unavailable/invalid input. |
| Narrow diagnostic avoids profile, orders, persistence, delivery and receipts | PASS | PASS | `TestPhase4BrokerAcceptance.test_success_uses_only_cash_quote_and_candles_and_preserves_separate_gates`; provider diagnostic guard tests. |
| Real authenticated quote + fresh completed-candle acceptance | NOT_TESTED | NOT_TESTED | A fresh separately authorized selected-provider diagnostic result and process exit are required. Upstox's earlier 403 is a failed historical attempt with unknown cause; it is not a new Phase 4 result. |

## Nine independent instrument and research scopes

| Scope | Upstox offline / live | Angel One offline / live | Source and tests | Required external evidence or implementation |
|---|---|---|---|---|
| 1. NSE cash quote | PASS / NOT_TESTED | PASS / NOT_TESTED | Existing `get_quote`; narrow diagnostic pins RELIANCE NSE_EQ `NSE_EQ|INE002A01018` / NSE token `2885`; Phase 4 full-wire acceptance tests. | Explicit authorization; selected-provider credentials/access; one fresh sanitized result proving matching mapping/echo where available, valid prices and provider observation age, plus exit code. No account/profile check is needed. |
| 2. Cash completed candles | PASS / NOT_TESTED | PASS / NOT_TESTED | Existing `get_intraday_candles`, shared validation and diagnostic completed-only sample; shared malformed/order/gap/freshness regressions. | An authorized current-session response with ordered complete interval/grid-valid OHLCV and matching identity. Upstox's existing V2 endpoint availability remains unverified; endpoint migration must be evidence-driven, not assumed necessary from a generic 403. |
| 3. NIFTY and BANK NIFTY index data | PASS for mappings and quotes; index-specific candles NOT_TESTED / NOT_TESTED | PASS for mappings and quotes; index-specific candles NOT_TESTED / NOT_TESTED | `spot_identity`, existing pinned indices; `TestPhase4BrokerAcceptance.test_both_index_spot_quote_mappings_are_checked_separately_from_cash_and_contracts`; shared index classification containment test. | Separate authorized index quote/candle evidence and current provider token/key confirmation. Initial narrow CLI scope is RELIANCE only. Index spot is `INDEX_SPOT`; index lot metadata does not make its candles executable futures/options. |
| 4. NSE F&O stock instruments | BLOCKED / NOT_TESTED | BLOCKED / NOT_TESTED | `spot_identity` supports cash equities/index spot; Angel master parser supports NSE shares and NIFTY/BANKNIFTY OPTIDX. `TestPhase4InstrumentScope.test_cash_instrument_cannot_be_relabelled_as_stock_fo_or_lot_sized`. | A current trusted stock-contract master and supported FUTSTK/OPTSTK resolution, expiry/strike/side/lot/multiplier identity, contract-bound data and independent tests. A RELIANCE share quote is not a RELIANCE derivative test. |
| 5. Futures instruments | BLOCKED / NOT_TESTED | BLOCKED / NOT_TESTED | `validate_signal_identity` rejects live futures lacking a resolver/candles. Archives/backtest configuration understand explicit FUTIDX research records but cannot authorize LIVE replay. Existing identity and archive tests plus new spot-versus-contract containment tests. | Dedicated unambiguous dated futures token, NFO type/underlying/expiry/lot/multiplier mapping and contract candles. Historical use additionally needs independently qualified original source evidence and effective intervals. |
| 6. Option contract / expiry / strike identity | BLOCKED for executable contracts / NOT_TESTED | PASS for local index-option identity checks; operational acceptance BLOCKED / NOT_TESTED | `option_contract`, Angel `_parse_and_validate_scrip_master_records`, `_quote_identity`; `TestPhase4InstrumentScope` requires every field and finite positive strike. Upstox `get_expiry_list` and chain parsing are analytical inputs; `option_contract` restricts supported executable proposal identity to master-resolved Angel index options. | Angel current complete master with nonexpired paired CE/PE contracts, exact NFO token/underlying/expiry/strike/side/lot/unit multiplier and master revision. Upstox needs its own supported contract identity/resolver path before executable option proposals. No fabricated tokens/lots or inferred expiry calendar. |
| 7. Chain and open-interest analytics | PASS for existing parser checks; signal readiness BLOCKED / NOT_TESTED | PASS for existing parser/baseline gates; operational readiness BLOCKED / NOT_TESTED | Upstox `get_option_chain` / `_normalize_option_chain_response`; Angel Greeks, quote-OI chain assembly and `get_option_apex_readiness`; existing Phase 2A/2B/2C and identity tests. | Separate entitled current chain/Greeks responses, matching underlying/expiry/strikes and consistent CE/PE OI. Angel needs a verified matching prior trading-session LIVE closing OI baseline with sufficient paired strikes. Analytical chain prices alone do not prove executable contract identity or option-candle fills. Narrow cash diagnostics do not call these endpoints. |
| 8. Authoritative historical master provenance | PASS for structural/integrity rejection; authenticity BLOCKED | PASS for structural/integrity rejection; authenticity BLOCKED | `instrument_archive.resolve_archive_declarations` vs `resolve_archives`; `source_qualification.assess_source_evidence`; `TestInstrumentArchives`, `TestSourceEvidenceQualification`, `TestOfficialSourceFeasibility`. | Original artifact/response bytes independently bound to publisher, source/capture evidence, authoritative instrument-specific historical validity intervals and a supported independent verifier. Current checkout implements no authenticity/date-authority verifier. URL, hash, filename, local ingestion time, supplied verified flag or archive pin cannot supply that proof. |
| 9. LIVE historical replay | BLOCKED | BLOCKED | `resolve_archives` rejects with HISTORICAL_SOURCE_EVIDENCE_INSUFFICIENT even after declaration consistency. Backtest/readiness tests reject forged/expired receipts, incomplete coverage and caller trust flags. Historical Strategy 3 remains blocked independently. | Satisfy source qualification first, then date-appropriate identity/contract coverage including warmup, complete eligible datasets/sessions, chronological evaluation and independent acceptance gates. Historical Strategy 3 additionally needs point-in-time option-chain/prior-close OI and true option-contract candle entry/exit/accounting support. A narrow diagnostic cannot issue the legacy Phase 2C receipt. |

The supported research archive schema is limited to EQ, INDEX_SPOT, FUTIDX and OPTIDX; it does not imply a current live adapter accepts all these execution types. The backtest engine supports EQ or explicit FUTIDX execution only; index spot remains reference-only and options execution is unsupported. Simulated research and fixture backtests must remain labelled SIMULATED.

## Reproduction and next authorized step

Run offline contract/provider tests from the project directory:

```powershell
python -B -W error::ResourceWarning -m unittest test_phase4_market_data test_market_data_contract test_angel_market_data -v
```

Configuration preflights are offline and do not change the selected broker:

```powershell
python -B .\upstox_diagnostics.py --symbol RELIANCE --check-config --json
python -B .\diagnostics.py --market-data-only --symbol RELIANCE --check-config --json
```

An unselected provider should be BLOCKED; do not edit selection or credentials to obtain a PASS. The actual preflight result is recorded in the engineering report.

After separate authorization, use **one** diagnostic for the explicitly selected provider during its configured NSE session with completed five-minute candles available. For the currently reported selected Upstox provider:

```powershell
python -B .\upstox_diagnostics.py --symbol RELIANCE --json
$LASTEXITCODE
```

This command contacts the existing quote endpoint and, only after an eligible quote, the intraday-candle endpoint. It does not call profile, funds, holdings, positions or trading endpoints. Stop after a rejection and review the sanitized status/code/message and exit code. No automatic retry loop or provider switch is part of this procedure. A successful result accepts only the tested RELIANCE cash-data path and cannot authorize F&O, historical replay or Strategy 3.

## Phase 5A/5B addendum: declaration and paper boundaries

The [current engineering report](TRADEPULSE_PHASE5A_ENGINEERING_REPORT.md) owns final
verification. Existing Phase 4 provider claims above retain their limited scope.
There was no new broker request or operational acceptance. Selected-Upstox
configuration preflight remains separate from authentication/candles; Angel remains
unselected, not disproven.

| Additional boundary | Status / evidence | Limit / exact next action |
| --- | --- | --- |
| Six-type local normalized contract declarations | PASS for structural validation/store reparse and explicit negative resolution, `test_phase5a_contracts` and integration tests | Every valid candidate stays BLOCKED_UNQUALIFIED_MASTER/eligible false. No current F&O universe or live contract-candle executor was added. Obtain attributable original master evidence and a supported conversion/trust boundary. |
| Historical authenticity/effective dates | BLOCKED; existing source gates plus 12 new adversarial provenance tests | No verifier/trust root or authoritative artifact is supplied. Resolve the actual acquisition/date-authority evidence design; preserve replay and Strategy 3 blocks. |
| Scanner to forward paper | PASS for offline cash implementation, `test_phase5b_forward` through actual mocked wire/real evaluator and real SQLite | Explicit immutable account plus next completed observation's close; every fill remains SIMULATED. No claim of liquidity, accepted broker observations, futures/options readiness or profitability. Next perform bounded offline multi-session/fault/EOD acceptance. |
| Account/contract inspection APIs | PASS for GET/HEAD/no mutation/no transport, `test_phase5a_integration` | Reporting does not scan, fill, create an account, download a master or issue a receipt. Large-ledger pagination remains work. |

## Continuous acceptance addendum - 2026-10-19

The [continuous report](TRADEPULSE_CONTINUOUS_ACCEPTANCE_REPORT.md) supersedes the
earlier next-task descriptions above. It records fresh baseline/final commands,
warnings, public-source capture and the precise remaining dependencies.

| Evidence layer | Actual result in this mission | Limit / next requirement |
| --- | --- | --- |
| Isolated Angel configuration | BLOCKED, exit 1: ANGEL_API_KEY, ANGEL_CLIENT_CODE, ANGEL_PIN and ANGEL_TOTP_SECRET are absent. `--isolated-provider --check-config` works without changing selected Upstox or requiring its credentials. | Configure those existing fields locally and repeat offline preflight; never disclose their values. |
| Angel authentication/quote/candles/freshness/session | NOT_TESTED against a real account. Narrow command is OFFLINE_TESTED/MOCK_TESTED, with no refresh/re-login retry. | One controlled appropriate-session RELIANCE read only after valid local configuration. A 403 is access denied, with cause unestablished; a quote alone cannot pass candles or issue a receipt. |
| Upstox current cash data | No new live request. Earlier reported 403 remains unexplained; selected provider unchanged. | The existing V2 intraday route is marked deprecated in [official documentation](https://upstox.com/developer/api-documentation/get-intra-day-candle-data/); document/test a narrow migration separately rather than attributing the 403 to deprecation. |
| Public Angel master | One credential-free public HTTPS capture; exact bytes retained losslessly with digests/time. Native inspection parses 3,059 observations across four derivative types for RELIANCE/NIFTY/BANKNIFTY. | Public-source capture is not authenticated broker-account acceptance or qualified current/historical contract authority. No active master was changed. |
| Native derivative data/execution | Four-class observation parser/lookup/store is OFFLINE_TESTED; real contract candle/fill acceptance remains BLOCKED/NOT_TESTED. | Accepted exact contract master, dates/units and provider-native candle path are separately required. Native lookup returns identity null / eligible false. |
| Historical source/studies | Source-bundle byte/scope checks and frozen study orchestration implemented; real signal quality NOT_TESTED. | No positive publisher/date/price-source authenticator or qualified historical dataset. LIVE replay and Strategy 3 remain blocked. |
| Paper/reporting | Recovery-audit freeze, bounded queue/inventory, EOD statement and stable ledger pages OFFLINE_TESTED. | No financial late repair, live feed acceptance, full event export or operational soak approval. |

No account-market observations were persisted, no receipt issued, no production
service started and no live Telegram message sent. Public documentation/master
requests are recorded separately from mocked and simulated test transport.
